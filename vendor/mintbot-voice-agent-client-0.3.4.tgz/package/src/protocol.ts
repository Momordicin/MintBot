// Wire types of the mintbot-voice-agent REST / SSE API (app/voice_agent.cpp lists the endpoints).

// The API level this client speaks; the agent reports its own in the ready line,
// /v1/health and `--version`.
export const API_VERSION = 1;

export interface AgentEvent {
  id: number;
  // status | speech_start | speech_end | final | command | speech_other | device | capture | error |
  // enroll_progress | enroll_failed | speaker | playback, plus "snapshot" from the supervisor (see VoiceAgentSupervisor)
  type: string;
  data: any;
}

export interface ReadyLine {
  type: "ready";
  port: number;
  pid: number;
  version: string;
  api_version: number;
}

// Speaker fields of `final` and `speech_other` (present when the agent runs with --spk-model).
export interface SpeakerFields {
  speaker_enrolled?: boolean; // a voiceprint exists; false = everything is transcribed
  speaker_score?: number; // cosine to the owner voiceprint (0 when not enrolled)
  speaker_threshold?: number; // the threshold applied to this utterance (agent >= 0.2.0)
  speaker_same_device?: boolean; // captured on the enrollment's microphone (agent >= 0.2.1)
  speaker_transcribe?: boolean; // the gate's decision to transcribe (agent >= 0.2.1)
  is_owner?: boolean; // speaker_score >= threshold (true when not enrolled)
  speaker_uncertain?: boolean; // shorter than --speaker-min-ms
  speaker_ms?: number; // time spent scoring when the utterance ended
  speaker_windows?: number; // 1.5 s windows scored
  speaker_reused?: number; // of which computed while the speech was going on
}

// Timing fields of `final` and `speech_other`.
export interface TimingFields {
  latency_ms: number; // segment closed -> event published
  queue_ms: number;
  detect_lag_ms: number; // segment end -> segment closed by the VAD
  total_ms: number; // segment end -> event published
  early: boolean; // the result was computed before the segment closed
}

// `final` event: one transcribed utterance (the owner's once a voiceprint exists).
export interface FinalEvent extends SpeakerFields, TimingFields {
  start_ms: number; // stream time
  end_ms: number;
  end_unix_ms: number;
  // after hotword correction; empty when the recognized text was only punctuation, e.g. a cough (agent >= 0.3.0)
  text: string;
  text_raw: string; // before hotword correction (agent >= 0.2.3)
  hotwords: HotwordReplacement[]; // replacements made in `text`, in order (agent >= 0.2.3)
  language: string; // e.g. "zh"
  emotion: string; // e.g. "NEUTRAL"
  event: string; // e.g. "Speech"
  raw: string; // with <|...|> tags
  asr_ms: number;
  // spoken during a running enrollment (it went into the voiceprint); only with --spk-model
  enrolling?: boolean;
}

export interface HotwordReplacement {
  from: string; // as recognized
  to: string; // the list's correct name
}

// `command` event (agent >= 0.2.3, with --wake-name): a `final` that calls the agent by name,
// at the start ("<name>, ...") or at the end ("..., <name>"); sent instead of `final`.
export interface CommandEvent extends FinalEvent {
  name: string; // the wake name
  command: string; // the rest of the utterance
}

// `speech_other` event: an utterance that is not the owner's; its text is never sent.
export interface SpeechOtherEvent extends SpeakerFields, TimingFields {
  start_ms: number;
  end_ms: number;
  end_unix_ms: number;
  // only when it is a cough, sneeze, laugh, cry, breath or applause (agent >= 0.3.0)
  event?: "Cough" | "Sneeze" | "Laughter" | "Cry" | "Breath" | "Applause";
  emotion?: string;
  asr_ms?: number; // agent >= 0.3.0
}

// `enroll_progress` event, and the answer of POST /v1/speaker/enroll/start
// (which also carries `active`).
export interface EnrollProgressEvent {
  active?: boolean;
  utterances: number;
  speech_ms: number;
  ready: boolean; // enough material for POST /v1/speaker/enroll/commit
}

// `enroll_failed` event: the running enrollment was stopped (agent >= 0.2.0).
export interface EnrollFailedEvent {
  code: "device_changed"; // the microphone changed during the enrollment
  message: string;
  display_name: string; // the new microphone
}

// The capture device, on `device` events and in GET /v1/status (agent >= 0.2.0);
// empty strings when unknown.
export interface DeviceIdentity {
  device_id: string; // Windows endpoint ID
  container_id: string; // physical device, shared by all endpoints of one headset
  display_name: string; // name to show, e.g. the headset's name
}

// `device` event.
export interface DeviceEvent extends DeviceIdentity {
  state: string; // started | stopped | rerouted | interrupted | resumed | stalled | ended
  name: string; // endpoint name
}

// GET /v1/speaker, the answers of enroll/commit, enroll/cancel and DELETE /v1/speaker,
// and the `speaker` event (after commit or forget). 404 without --spk-model.
export interface SpeakerStatus {
  enrolled: boolean;
  utterances: number; // in the voiceprint
  speech_ms: number;
  threshold: number;
  min_reliable_ms: number;
  gate_uncertain: boolean;
  uncertain_floor: number;
  // agent >= 0.2.0
  enrolled_device?: string; // microphone the voiceprint was enrolled on; "" if unknown
  device?: string; // current microphone
  active_threshold?: number; // on another microphone: the value for a 1 s utterance
  active_uncertain_floor?: number;
  // agent >= 0.2.1: on another microphone the threshold is cross_base + cross_per_ln_s * ln(seconds),
  // not below cross_min
  same_device?: boolean;
  cross_base?: number;
  cross_per_ln_s?: number;
  cross_min?: number;
  enrolling: boolean;
  enroll_utterances: number; // collected by the running enrollment
  enroll_speech_ms: number;
  enroll_ready: boolean;
  persistent: boolean; // --speaker-db given: the voiceprint is kept in a file
}

// GET /v1/hotwords and `hotwords` in GET /v1/status (agent >= 0.2.4).
export interface HotwordsStatus {
  path: string; // the loaded list; "" if none
  entries: number;
  role: string; // id of the current character; "" if none
  role_name: string;
  roles: { id: string; name: string; entries: number }[]; // one per "# <character> <date> <id>" section
  wake_name: string;
}

// 200 answer of POST /v1/hotwords/reload[?path=FILE][&role=ID] (agent >= 0.2.4).
export interface HotwordsReloadReply extends HotwordsStatus {
  role_found: boolean; // false: `role` is not in the list, no character is current
}

// 400 answer of POST /v1/hotwords/reload: the previous list stays loaded.
export interface HotwordsReloadError {
  error: string;
  code: "no_path" | "file_unreadable" | "not_utf8";
  hotwords?: HotwordsStatus; // absent when path or role was not UTF-8
}

// `playback` event (agents with playback): one per state of each clip queued with POST /v1/play.
// An event for an id can arrive before POST /v1/play answers with that id: keep the events
// of ids not known yet. Ids belong to one agent process and start at 1 in each; when the
// agent exits, its outstanding clips may end without an event (an agent shutdown can still
// send "stopped" for them before the event stream closes). Events reach connected streams
// only: until the first `status` event of an event connection, playback events may have
// been missed, and that status gives counts (PlaybackStatus), not ids.
export interface PlaybackEvent {
  // start: its first sample went to the output device; end: its last one did;
  // stopped: POST /v1/playback/stop, the agent's shutdown, or an output device problem ended
  // it. An `error` event with code "playback_failed" is sent when a playing clip is cut
  // because the device stopped and did not come back within 2 s, or when the device cannot
  // be opened for queued clips
  state: "start" | "end" | "stopped";
  id: number; // the answer of POST /v1/play
}

// `playback` in GET /v1/status, and the answer of POST /v1/playback/stop (agents with playback).
// Counts only: which ids are playing or queued is known from the events alone.
export interface PlaybackStatus {
  playing: boolean; // a clip has started and not ended
  queued: number; // clips not started yet
}

// Error codes of POST /v1/listen/start and of `capture` events.
export type CaptureErrorCode = "mic_access_denied" | "capture_failed" | "";

export class AgentHttpError extends Error {
  readonly status: number;
  readonly body: any;
  constructor(method: string, path: string, status: number, body: any) {
    super(`${method} ${path}: ${status} ${typeof body === "string" ? body : JSON.stringify(body)}`);
    this.name = "AgentHttpError";
    this.status = status;
    this.body = body;
  }
  // `code` of the error body, e.g. "mic_access_denied"
  get code(): string | undefined {
    return typeof this.body?.code === "string" ? this.body.code : undefined;
  }
}
